package model;

/**
 *
 * @author CETECOM
 */
public class Calculadora {
    public Double sumarNumeros(double a, double b){
        return a + b;
    }
    public Double restarNumeros(double a, double b){
        return a-b;
    }
    public Double dividirNumeros(double a,double b){
        return a/b;
    }
    public Double multiplicarNumeros(double a, double b)throws Exception{
    if(b!=0){
        return a*b;
    }else{
        throw new Exception("");
        }
    }
}
