/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import javax.swing.JOptionPane;

/**
 *
 * @author CETECOM
 */
public class Mensajes {
     
    public static void mostrarMensaje(String mensaje,String titulo, int icono ){
        JOptionPane.showMessageDialog(null, mensaje,titulo,icono);
    }
}
