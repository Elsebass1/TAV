package ejemplomvc;

import controller.CalculadoraController;
import model.Calculadora;
import view.CalculadoraView;

/**
 *
 * @author CETECOM
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        CalculadoraView v = new CalculadoraView();
        Calculadora m = new Calculadora();
        CalculadoraController ctrl = new CalculadoraController(v, m);
        //v.setVisible(true);"NO HACER ESTO"   
    }
    
}
