package controller;

import model.Calculadora;
import view.CalculadoraView;
import view.Mensajes;

/**
 *
 * @author CETECOM
 */
public class CalculadoraController {
    private CalculadoraView vista;
    private Calculadora modelo;
    
    private double n1;
    private double n2;
    
    public CalculadoraController(CalculadoraView vista, Calculadora modelo) {
        this.vista = vista;
        this.modelo = modelo;
        init();
    }

    private void init() {
        
        vista.getBtnSumar().addActionListener((e)->{
           sumar(); 
        });
        vista.getBtnRestar().addActionListener((e)->{
            restar();
        });
        vista.getBtnDividir().addActionListener((e)->{
            dividir();
        });
        vista.getBtnMultiplicar().addActionListener((e)->{
            multiplicar();
        });
        vista.getBtnLimpiar().addActionListener((e)->{
            limpiar();
        });
        vista.setVisible(true);
    }
    private void capturarNumeros(){
        try{
        n1 = Double.parseDouble(vista.getTxt1().getText());
        n2 = Double.parseDouble(vista.getTxt2().getText());
        }catch (NumberFormatException numberFormatException){
            Mensajes.mostrarMensaje("Debe ingresar numeros", "Error", 0);
        }
        }
    private void sumar() {
        capturarNumeros();
        double resultado = modelo.sumarNumeros(n1, n2);
        vista.getTxtResultado().setText(String.valueOf(resultado));
        //System.out.println("ESTO DEBE SUMAR!!! " + n1 + " Y " + n2);
    }
    private void restar(){
        capturarNumeros();
        double resultado = modelo.restarNumeros(n1, n2);
        vista.getTxtResultado().setText(String.valueOf(resultado));
        //System.out.println("ESTO DEBE SUMAR!!! " + n1 + " Y " + n2);
    }
    private void dividir(){
        capturarNumeros();
        double resultado = modelo.dividirNumeros(n1, n2);
        vista.getTxtResultado().setText(String.valueOf(resultado));
        //System.out.println("ESTO DEBE SUMAR!!! " + n1 + " Y " + n2);
    }
    private void multiplicar(){
        capturarNumeros();
        double resultado = modelo.multiplicarNumeros(n1, n2);
        vista.getTxtResultado().setText(String.valueOf(resultado));
        //System.out.println("ESTO DEBE SUMAR!!! " + n1 + " Y " + n2);
    }
    private void limpiar(){
        vista.getTxt1().setText("");
        vista.getTxt2().setText("");
        vista.getTxtResultado().setText("");
    }
}

