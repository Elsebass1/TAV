/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author CETECOM
 */
public class Registro {
    private ArrayList personas;
    //constructor vacio
    public Registro() {
        personas = new ArrayList();
    }
    //agregar
    public void agregar(Persona persona)throws Exception{
        Persona p = buscarXrut(persona.getRut());
        if (p == null){
            personas.add(persona);
        }else{
            throw new Exception("La persona ya exciste ");
        }
    }
    // lista 
    public ArrayList listar(){
        return personas;
    } 
    // modificar 
    //eliminar
    // buscarXrut
    public Persona buscarXrut(String rut ){
        for (Object objeto : personas){
            Persona buscada =(Persona)objeto;
            if(buscada.getRut().equals(rut)){
                return buscada;
            }
        }
        return null;
    }
}
