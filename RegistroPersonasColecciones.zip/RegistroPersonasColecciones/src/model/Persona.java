/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;

/**
 *
 * @author CETECOM
 */
public class Persona {
    private String rut;
    private String nombre;
    private String apellido;
    private LocalDate fecha_ncto;

    public Persona(String rut, String nombre, String apellido, LocalDate fecha_ncto) throws Exception {
        this.setRut(rut);
        this.nombre = nombre;
        this.apellido = apellido;
        this.fecha_ncto = fecha_ncto;
    }

    public LocalDate getFecha_ncto() {
        return fecha_ncto;
    }

    public void setFecha_ncto(LocalDate fecha_ncto) {
        this.fecha_ncto = fecha_ncto;
    }

    public String getRut() {
        return rut;
    }

    public void setRut(String rut)throws Exception {
        if(rut.length()>= 3){
        this.rut = rut;
        }else{
            throw new Exception("Debe agregar un rut");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("rut: ").append(rut);
        sb.append(" \nnombre: ").append(nombre);
        sb.append(" \napellido: ").append(apellido);
        sb.append(" \nfecha nacimiento: ").append(fecha_ncto);
        return sb.toString();
    }
    
    
}
