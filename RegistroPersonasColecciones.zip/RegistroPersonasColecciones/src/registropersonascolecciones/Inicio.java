/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package registropersonascolecciones;

import java.time.LocalDate;
import java.time.Month;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Persona;
import model.Registro;

/**
 *
 * @author CETECOM
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Persona p = new Persona ("100","wacoldo","soto",LocalDate.of(1990, Month.MARCH, 5));
            
            Registro r= new Registro();
            
            r.agregar(p);

            
            Persona d = new Persona ("200000","Reinaldo","castro",LocalDate.of(2000, Month.MARCH, 10));
            r.agregar(d);
            System.out.println(r.listar());
            
            
        } catch (Exception ex) {
            Logger.getLogger(Inicio.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
