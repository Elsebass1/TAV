package ejecicioguitarras2;

import model.Acustica;
import model.Electrica;
import model.Guitarra;
import model.Registro;

/**
 *
 * @author sebas
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Registro db = new Registro();
            db.AgregarGuitarra(new Electrica(2,true,100,"Strato",6,100000));
            db.AgregarGuitarra(new Electrica(4,false,200,"Jackson",8,200000));
            db.AgregarGuitarra(new Acustica("Cholguan","pino",300,"Vega",5,10000));
            System.out.println("******Precios******");
            for(Guitarra guitar : db.getGuitars()){
                System.out.println(guitar.calcularValor());
            }
            System.out.println("Total Electricas: " + db.totalElectricas());
            System.out.println("Total inventario: $"+ db.totalInventario());
            
            
            
            
            
            
        } catch (Exception ex) {
            System.getLogger(Inicio.class.getName()).log(System.Logger.Level.ERROR, (String) null, ex);
        }
    }
    
}
