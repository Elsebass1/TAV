/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author sebas
 */
public class Registro {
    ArrayList<Guitarra> guitars;

    public Registro() {
        guitars = new ArrayList();
    }
    public void AgregarGuitarra(Guitarra guitarra)throws Exception{
        for (Guitarra guitar : guitars){
            if(guitar.getId()  == guitarra.getId()){
                throw new Exception("El id ya existe: ");
            }
        }
        guitars.add(guitarra);
    }
    public ArrayList<Guitarra> getGuitars(){
            return guitars;
    }
    public ArrayList<Electrica> getElectricas(){
        ArrayList<Electrica> elec = new ArrayList();
        for (Guitarra guitar : guitars){
            if(guitar instanceof Electrica){
                elec.add((Electrica)guitar);
            }
        }
        return elec;
    }
    public int totalElectricas(){
        return getElectricas().size();
    }
    public double totalInventario(){
    double total = 0;
    for (Guitarra guitar : guitars){
        total += guitar.calcularValor();
        }
    return total;
    }
}
