package model;

/**
 *
 * @author sebas
 */
public abstract class Guitarra implements IGuitarras{
    private int id;
    private String modelo;
    private int cuerdas;
    protected double precio;

    public Guitarra(int id, String modelo, int cuerdas, double precio) {
        this.id = id;
        this.modelo = modelo;
        this.cuerdas = cuerdas;
        this.precio = precio;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getCuerdas() {
        return cuerdas;
    }

    public void setCuerdas(int cuerdas) {
        this.cuerdas = cuerdas;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("id=").append(id);
        sb.append("\nmodelo : ").append(modelo);
        sb.append("\ncuerdas : ").append(cuerdas);
        sb.append("\nprecio : ").append(precio);
        
        return sb.toString();
    }

    @Override
    public abstract double calcularValor();
    
    
}
