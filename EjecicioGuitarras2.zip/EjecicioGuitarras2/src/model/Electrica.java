package model;

/**
 *
 * @author sebas
 */
public final class Electrica extends Guitarra{
    private int capsulas;
    private boolean activa;

    public Electrica(int capsulas, boolean activa, int id, String modelo, int cuerdas, double precio) {
        super(id, modelo, cuerdas, precio);
        this.capsulas = capsulas;
        this.activa = activa;
    }

    public boolean isActiva() {
        return activa;
    }

    public void setActiva(boolean activa) {
        this.activa = activa;
    }

    public int getCapsulas() {
        return capsulas;
    }

    public void setCapsulas(int capsulas) {
        this.capsulas = capsulas;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Guitarra Electrica");
        sb.append(super.toString());
        sb.append(" \ncapsulas : ").append(capsulas);
        sb.append(" \nactiva : ").append(activa);
        return sb.toString();
    }

    @Override
    public double calcularValor() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return precio*FACTOR_ELECTRICA;
    }
    
}
