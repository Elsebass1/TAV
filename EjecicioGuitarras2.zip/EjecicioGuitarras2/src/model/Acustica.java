package model;

/**
 *
 * @author sebas
 */
public final class Acustica extends Guitarra{
    private String cuerpo;
    private String mastil;

    public Acustica(String cuerpo, String mastil, int id, String modelo, int cuerdas, double precio) {
        super(id, modelo, cuerdas, precio);
        this.cuerpo = cuerpo;
        this.mastil = mastil;
    }

    public String getMastil() {
        return mastil;
    }

    public void setMastil(String mastil) {
        this.mastil = mastil;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Guitarra Acustica");
        sb.append(" \ncuerpo: ").append(cuerpo);
        sb.append(super.toString());
        sb.append(" \nmastil: ").append(mastil);
        return sb.toString();
    }

    @Override
    public double calcularValor() {
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return precio*FACTOR_ACUSTICA;
    }
    
    
    
}
