package model;

/**
 *
 * @author sebas
 */
public interface IGuitarras {
    double FACTOR_ACUSTICA = 1.5;
    double FACTOR_ELECTRICA = 2.0;
    
    double calcularValor();
}
