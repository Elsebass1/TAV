/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package instrumentomvc;

import bd.Conexion;
import java.sql.Connection;

/**
 *
 * @author CETECOM
 */
public class Inicio {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Conexion conn = new Conexion();
        Connection db = conn.conectar();
        if(db!= null){
            System.out.println("Estamos conectados");
        }
        else
        {
            System.out.println("Watio la conexion");    
        }
    }
    
}
