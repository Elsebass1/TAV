/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Alejandro
 */
public class Conexion {
    Connection conectar=null;
    String servidor = "127.0.0.1";
    String baseDatos = "musicadb";
    String usuario = "root";
    String password = "";
    public Connection conectar(){
       try {
          Class.forName("com.mysql.cj.jdbc.Driver");
          //conectar=DriverManager.getConnection("jdbc:mysql:"
          //          + "//localhost/productos", "root","");
          conectar=DriverManager.getConnection("jdbc:mysql:"
                    + "//"+ servidor + "/" + baseDatos, usuario, password);
       } catch (Exception e) {
            JOptionPane.showMessageDialog(null,e.getMessage());
       }
       return conectar;
    }
}

