package model;

/**
 *
 * @author CETECOM
 */
public class Instrumento {
    private int id;
    private String marca;
    private int precio;

    public Instrumento(int id, String marca, int precio) {
        this.id = id;
        this.marca = marca;
        this.precio = precio;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
}
